import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

export class Book {
  title: string;
  subtitle: string;
  currentPage: number;
  lastPage: boolean;
  maxPages: number;
}

export class Page {
  pageNumber: number;
  title: string;
  subtitle: string;
  chapter: number;
  content: string;
  image: string;
  page: boolean;
}

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

  book: Book = {
    title: 'S.H.I.E.L.D.',
    subtitle: 'Classified',
    currentPage: 0,
    lastPage: false,
    maxPages: null
  }

  pages: Page[] = [
    {
      page: false,
      pageNumber: 0,
      title: this.book.title,
      subtitle: this.book.subtitle,
      chapter: null,
      content: null,
      image: null
    },
    {
      page: false,
      pageNumber: 1,
      title: 'Table of Contents',
      subtitle: null,
      chapter: null,
      content: null,
      image: null
    },
    {
      page: false,
      pageNumber: 2,
      title: 'Prologue',
      subtitle: null,
      chapter: null,
      content: '"There was an idea, Stark knows this, called the Avengers Initiative. The idea was to bring together a group of remarkable people, to see if they could become something more. To fight the battles that we never could."-Nick Fury',
      image: 'https://fsmedia.imgix.net/a0/00/6b/6e/5fd3/4f4a/9a43/abaed622fa17/captain-america-the-winter-soldier-2014.jpeg?rect=0%2C289%2C2880%2C1439&auto=format%2Ccompress&dpr=2&w=650'
    },
    {
      page: false,
      pageNumber: 3,
      title: 'Chapter 1: Captain America',
      subtitle: null,
      chapter: 1,
      content: 'Rogers joined their ranks as the first recruit, since their formation, and was given retroactive "founding member" status in place of Hulk. With his superhuman abilities, extensive training, combat experience, combined with his impressive physique, confidence, and will, Rogers was an excellent addition to the team. As a born leader, Rogers would come to be seen as the heart and soul of the team and his commands, while in the field, were often followed regardless of who might have been team leader at the time. Rogers would teach teamwork, tactics, and hand-to-hand combat to many Avengers over the coming years.',
      image: 'https://pmcvariety.files.wordpress.com/2017/07/captain-america-4th-of-july.jpg?w=1000'
    },
    {
      page: true,
      pageNumber: 4,
      title: null,
      subtitle: null,
      chapter: null,
      content: 'Vestibulum pretium mauris quis nisl iaculis vehicula. Cras egestas est fermentum eleifend viverra. Integer elementum ut magna non interdum. Maecenas eleifend nisl vitae lectus interdum, eu volutpat justo venenatis. Maecenas suscipit tellus tortor, et dapibus ante elementum et. Quisque sagittis venenatis diam, non placerat dui cursus eu. Integer quis augue nisl. Proin dui est, sollicitudin quis lectus eu, commodo bibendum velit. Nullam ac massa tincidunt, vehicula sem ut, venenatis lacus. Suspendisse at dui nec lorem cursus eleifend. Cras justo nunc, venenatis eget sodales eu, posuere a diam. Nulla finibus posuere varius. Donec et scelerisque arcu. Vestibulum non feugiat ligula. Nullam odio felis, iaculis at convallis ac, condimentum quis tortor. Maecenas lacinia arcu ac vestibulum consectetur.',
      image: 'https://pmcvariety.files.wordpress.com/2017/07/captain-america-4th-of-july.jpg?w=1000'
    },
    {
      page: false,
      pageNumber: 5,
      title: 'Chapter 2: Iron Man',
      subtitle: null,
      chapter: 2,
      content: 'Since that first suit built in a cave, Tony has created dozens of new suits and upgrades over the years. However, throughout the 50-plus Iron Man models, there are common offensive and defense capabilities found in most iterations.',
      image: 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/ironman-spiderman-homecoming-poster-frontpage-700x354.jpg'
    },
    {
      page: false,
      pageNumber: 6,
      title: 'Chapter 3: Hulk',
      subtitle: null,
      chapter: 3,
      content: 'For years, Id been treating the Hulk like hes some kind of disease, something to get rid of. But then I started looking at him as the cure. Eighteen months in a gamma lab. I put the brains and the brawn together. And now look at me. Best of both worlds. -Bruce Banner',
      image: 'https://cdn3.movieweb.com/i/article/ioq9yaAKGWigl9ElWF0EPDovP4whtZ/798:50/Avengers-Endgame-Professor-Hulk-True-Purpose-Infinity-War.jpg'
    },
    {
      page: false,
      pageNumber: 7,
      title: 'Chapter 4: Thor',
      subtitle: null,
      chapter: 4,
      content: 'Thor Odinson is the Asgardian God of Thunder, the former king of Asgard and New Asgard, and a founding member of the Avengers. When his irresponsible and impetuous behavior reignited a conflict between Asgard and Jotunheim, Thor was denied the right to become king, stripped of his power, and banished to Earth by Odin. While exiled on Earth, Thor learned humility, finding love with Jane Foster, and helped save his new friends from the Destroyer sent by Loki. Due to his selfless act of sacrifice, Thor redeemed himself in his fathers eyes and was granted his power once more, which he then used to defeat Lokis schemes of genocide.',
      image: 'https://cdn.mcuexchange.com/wp-content/uploads/2018/06/thor.jpg'
    },
    {
      page: false,
      pageNumber: 8,
      title: 'The End',
      subtitle: 'Thank You Stan Lee',
      chapter: null,
      content: null,
      image: 'https://cdnph.upi.com/svc/sv/upi/1731542111394/2018/1/758c6b6c4e1f4b0987c7afcd0ec8637d/Marvel-film-stars-pay-tribute-to-Stan-Lee-There-will-never-be-another.jpg'
    }
  ]

  goToPage(page) {
    this.book.currentPage = page;
    if (this.book.maxPages - 1 === this.book.currentPage) this.book.lastPage = true;
  }

  prevPage() {
    if (this.book.currentPage < this.book.maxPages) this.book.lastPage = false;
    if (this.book.currentPage === 0) return;
    this.book.currentPage -= 1;
  }

  nextPage() {
    if (this.book.maxPages === null) {
      this.book.maxPages = this.pages.length;
    }
    if (this.book.lastPage === true) return;
    this.book.currentPage += 1;
    if (this.book.maxPages - 1 === this.book.currentPage) this.book.lastPage = true;
  }
}